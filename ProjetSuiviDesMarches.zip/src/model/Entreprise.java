package model;

public class Entreprise {

}
