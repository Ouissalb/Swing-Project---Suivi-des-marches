package model;

public class Prestataire {

}
