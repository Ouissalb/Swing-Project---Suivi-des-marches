package model;

public class Commentaire {
    
}