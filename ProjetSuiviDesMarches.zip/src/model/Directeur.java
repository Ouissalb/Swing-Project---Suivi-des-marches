package model;

public class Directeur {

}
