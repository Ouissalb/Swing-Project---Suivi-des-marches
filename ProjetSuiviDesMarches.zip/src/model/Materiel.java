package model;

public class Materiel {
    private String materiel;
    
    public Materiel()
    {        
    }
    
    public Materiel(String m)
    {
        this.materiel = m;
    }
}