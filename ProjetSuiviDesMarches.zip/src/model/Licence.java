package model;

public class Licence {
    private String licence;
    
    public Licence()
    {        
    }
    
    public Licence(String l)
    {
        this.licence = l;
    }
}