
package controller;
public class MonException extends Exception{
    public MonException()
    {
        super();
    }
    
    public MonException (String m)
    {
        super(m);
    }    
}